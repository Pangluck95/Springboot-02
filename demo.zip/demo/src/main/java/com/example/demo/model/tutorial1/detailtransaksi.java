/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo.model.tutorial1;

import com.example.demo.model.Barang;
import java.util.List;

/**
 *
 * @author pangestu
 */
public class detailtransaksi {
    List<Barang> Barang;

    public List<Barang> getBarang() {
        return Barang;
    }

    public void setBarang(List<Barang> Barang) {
        this.Barang = Barang;
    }
    
}
